<?php
/**
 * Plugin Name: Kampania Linki
 * Description: Skracanie linków, statystyki kliknięć, raporty PDF, QR i REST API.
 * Version: 1.0
 * Author: Twoje Imię
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once plugin_dir_path(__FILE__) . 'includes/class-loader.php';

function kampania_linki_activate() {
    require_once plugin_dir_path(__FILE__) . 'includes/class-install.php';
    KampaniaLinki_Install::run();
}
register_activation_hook(__FILE__, 'kampania_linki_activate');
