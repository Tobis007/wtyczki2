# Kampania Linki

Wtyczka WordPress do skracania linków, zbierania kliknięć, generowania raportów PDF, QR kodów i integracji z REST API.

## Funkcje
- Skracanie linków z aliasem
- Zliczanie kliknięć (IP, referrer, user-agent)
- Raporty PDF z wykresami dziennymi i miesięcznymi
- Generowanie QR kodów
- REST API do generowania i statystyk
